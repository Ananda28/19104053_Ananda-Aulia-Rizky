@extends('base')

@section('content')
    <h1>
        Ananda Aulia Rizky
    </h1>
@endsection
